package com.dizz.player

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Тема интерфейса: по обложке трека или свой цвет. Все цвета строятся от одного оттенка. */
object Pal {
    private fun hue(): Float = if (Cfg.themeMode == 1) Cfg.themeHue else Look.hue
    private fun sat(): Float = if (Cfg.themeMode == 1) Cfg.themeSat else Look.sat
    private fun hsl(h: Float, s: Float, l: Float): Color =
        Color(hslToArgb((((h % 360f) + 360f) % 360f) / 360f, s.coerceIn(0f, 1f), l, 1f))

    fun bgTop() = hsl(hue(), sat() * 0.6f, 0.16f)
    fun bgBottom() = hsl(hue(), sat() * 0.65f, 0.07f)
    fun container() = hsl(hue(), sat() * 0.75f, 0.22f)
    fun primary() = hsl(hue(), min(1f, sat() * 1.15f), 0.72f)
    fun onPrimary() = hsl(hue(), sat() * 0.8f, 0.10f)
    fun accent() = hsl(hue(), min(1f, sat() * 1.2f), 0.75f)
    fun blob(i: Int): Color = when (i % 3) {
        0 -> hsl(hue(), min(1f, sat() * 1.2f), 0.50f)
        1 -> hsl(hue() + 38f, min(1f, sat() * 1.2f), 0.50f)
        else -> hsl(hue() - 38f, min(1f, sat() * 1.2f), 0.45f)
    }
}

private val noiseBrush: ShaderBrush by lazy {
    val n = 96
    val px = IntArray(n * n) { val g = (Math.random() * 255).toInt(); android.graphics.Color.argb(255, g, g, g) }
    val b = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    ShaderBrush(ImageShader(b.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
}

/** Переливающийся фон в цветах темы: медленно плывущие пятна, на бите вспыхивают и «дышат». */
@Composable
fun AuroraBg(modifier: Modifier) {
    Canvas(modifier) {
        val t = Clock.t / 1_000_000_000f
        val w = size.width
        val h = size.height
        val sens = Cfg.shimmer
        val pulse = Engine.pulse * sens
        var bass = 0f
        for (i in 0 until 6) bass += Engine.shown[i]
        bass = bass / 6f * sens
        drawRect(Brush.verticalGradient(listOf(Pal.bgTop(), Pal.bgBottom())))
        for (i in 0 until 5) {
            val ph = t * (0.10f + i * 0.037f) + i * 1.9f
            val c = Offset(w * (0.5f + 0.45f * sin(ph * 1.13f + i)), h * (0.5f + 0.42f * cos(ph * 0.87f + i * 2.1f)))
            val r = w * (0.62f + 0.16f * sin(ph * 1.7f)) * (1f + 0.10f * pulse + 0.18f * bass)
            val a = (0.20f + 0.08f * sin(ph * 2.3f) + 0.30f * pulse + 0.20f * bass).coerceIn(0f, 0.85f)
            drawCircle(
                Brush.radialGradient(listOf(Pal.blob(i).copy(alpha = a), Color.Transparent), center = c, radius = r),
                r, c, blendMode = BlendMode.Plus
            )
        }
        if (pulse > 0.02f) drawRect(Pal.accent().copy(alpha = (0.10f * pulse).coerceIn(0f, 0.25f)), blendMode = BlendMode.Plus)
    }
}

/** «Матовое стекло»: лёгкое затемнение и мелкое зерно поверх размытого фона. */
@Composable
fun FrostOverlay(modifier: Modifier) {
    Canvas(modifier) {
        drawRect(Color.Black.copy(alpha = 0.16f))
        drawRect(noiseBrush, alpha = 0.05f)
    }
}
