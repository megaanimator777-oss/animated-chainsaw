package com.dizz.player

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Cfg {
    private var sp: SharedPreferences? = null
    var apiKey by mutableStateOf("")
    var provider by mutableIntStateOf(0)       // 0 = Groq, 1 = OpenAI
    var aiLang by mutableStateOf("")
    var aiInBatch by mutableStateOf(false)
    var style by mutableIntStateOf(0)
    var palette by mutableIntStateOf(5)
    var gain by mutableFloatStateOf(1f)
    var particles by mutableStateOf(true)
    var flashOn by mutableStateOf(false)
    var flashBand by mutableIntStateOf(0)      // 0 bass, 1 mid, 2 high, 3 all
    var flashSens by mutableFloatStateOf(0.6f)
    var flashLen by mutableFloatStateOf(70f)
    var flashGap by mutableFloatStateOf(200f)
    var flashBright by mutableFloatStateOf(1f)
    var flashMode by mutableIntStateOf(1)        // 0 фонарик, 1 экран, 2 оба
    var screenColor by mutableIntStateOf(0)      // 0..8 цвета, 9 свой, 10 радуга
    var screenHue by mutableFloatStateOf(280f)
    var screenBright by mutableFloatStateOf(0.8f)
    var screenLen by mutableFloatStateOf(220f)
    var showCover by mutableStateOf(true)
    var coverShape by mutableIntStateOf(0)       // 0 круг, 1 скруглённый квадрат
    var coverSize by mutableFloatStateOf(0.42f)
    var vizQuality by mutableFloatStateOf(0.7f)
    var vizTrails by mutableStateOf(false)
    var vizBg by mutableStateOf(true)
    var vizAlpha by mutableFloatStateOf(0.9f)
    var blurDp by mutableFloatStateOf(28f)
    var shimmer by mutableFloatStateOf(1f)
    var themeMode by mutableIntStateOf(0)        // 0 по обложке, 1 свой цвет
    var themeHue by mutableFloatStateOf(150f)
    var themeSat by mutableFloatStateOf(0.55f)
    var favs by mutableStateOf<Set<Long>>(emptySet())
    var waveNovelty by mutableFloatStateOf(0.25f)
    var jamendoOn by mutableStateOf(false)
    var jamendoId by mutableStateOf("")
    var vizPos by mutableFloatStateOf(0.62f)
    var vizBlurDp by mutableFloatStateOf(2f)
    var autoCover by mutableStateOf(true)
    var seekStyle by mutableIntStateOf(0)        // 0 зеркальные столбики, 1 волна

    fun init(c: Context) {
        if (sp != null) return
        val s = c.getSharedPreferences("dizz", Context.MODE_PRIVATE)
        sp = s
        apiKey = s.getString("apiKey", "") ?: ""
        provider = s.getInt("provider", 0)
        aiLang = s.getString("aiLang", "") ?: ""
        aiInBatch = s.getBoolean("aiInBatch", false)
        style = s.getInt("style", 0)
        palette = s.getInt("palette", 5)
        gain = s.getFloat("gain", 1f)
        particles = s.getBoolean("particles", true)
        flashOn = s.getBoolean("flashOn", false)
        flashBand = s.getInt("flashBand", 0)
        flashSens = s.getFloat("flashSens", 0.6f)
        flashLen = s.getFloat("flashLen", 70f)
        flashGap = s.getFloat("flashGap", 200f)
        flashBright = s.getFloat("flashBright", 1f)
        flashMode = s.getInt("flashMode", 1)
        screenColor = s.getInt("screenColor", 0)
        screenHue = s.getFloat("screenHue", 280f)
        screenBright = s.getFloat("screenBright", 0.8f)
        screenLen = s.getFloat("screenLen", 220f)
        showCover = s.getBoolean("showCover", true)
        coverShape = s.getInt("coverShape", 0)
        coverSize = s.getFloat("coverSize", 0.42f)
        vizQuality = s.getFloat("vizQuality", 0.7f)
        vizTrails = s.getBoolean("vizTrails", false)
        vizBg = s.getBoolean("vizBg", true)
        vizAlpha = s.getFloat("vizAlpha", 0.9f)
        blurDp = s.getFloat("blurDp", 28f)
        shimmer = s.getFloat("shimmer", 1f)
        themeMode = s.getInt("themeMode", 0)
        themeHue = s.getFloat("themeHue", 150f)
        themeSat = s.getFloat("themeSat", 0.55f)
        favs = (s.getStringSet("favs", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
        waveNovelty = s.getFloat("waveNovelty", 0.25f)
        jamendoOn = s.getBoolean("jamendoOn", false)
        jamendoId = s.getString("jamendoId", "") ?: ""
        vizPos = s.getFloat("vizPos", 0.62f)
        vizBlurDp = s.getFloat("vizBlurDp", 2f)
        autoCover = s.getBoolean("autoCover", true)
        seekStyle = s.getInt("seekStyle", 0)
    }

    fun save() {
        val e = sp?.edit() ?: return
        e.putString("apiKey", apiKey)
        e.putInt("provider", provider)
        e.putString("aiLang", aiLang)
        e.putBoolean("aiInBatch", aiInBatch)
        e.putInt("style", style)
        e.putInt("palette", palette)
        e.putFloat("gain", gain)
        e.putBoolean("particles", particles)
        e.putBoolean("flashOn", flashOn)
        e.putInt("flashBand", flashBand)
        e.putFloat("flashSens", flashSens)
        e.putFloat("flashLen", flashLen)
        e.putFloat("flashGap", flashGap)
        e.putFloat("flashBright", flashBright)
        e.putInt("flashMode", flashMode)
        e.putInt("screenColor", screenColor)
        e.putFloat("screenHue", screenHue)
        e.putFloat("screenBright", screenBright)
        e.putFloat("screenLen", screenLen)
        e.putBoolean("showCover", showCover)
        e.putInt("coverShape", coverShape)
        e.putFloat("coverSize", coverSize)
        e.putFloat("vizQuality", vizQuality)
        e.putBoolean("vizTrails", vizTrails)
        e.putBoolean("vizBg", vizBg)
        e.putFloat("vizAlpha", vizAlpha)
        e.putFloat("blurDp", blurDp)
        e.putFloat("shimmer", shimmer)
        e.putInt("themeMode", themeMode)
        e.putFloat("themeHue", themeHue)
        e.putFloat("themeSat", themeSat)
        e.putStringSet("favs", favs.map { it.toString() }.toSet())
        e.putFloat("waveNovelty", waveNovelty)
        e.putBoolean("jamendoOn", jamendoOn)
        e.putString("jamendoId", jamendoId)
        e.putFloat("vizPos", vizPos)
        e.putFloat("vizBlurDp", vizBlurDp)
        e.putBoolean("autoCover", autoCover)
        e.putInt("seekStyle", seekStyle)
        e.apply()
    }
}
