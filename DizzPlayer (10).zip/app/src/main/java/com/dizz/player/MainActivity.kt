@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.dizz.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import kotlin.math.sin
import kotlin.math.PI
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.draw.blur
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.animation.Crossfade
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.drawText
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.State
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0B0B14)
private val acc: Color get() = Pal.accent()

class MainActivity : ComponentActivity() {
    private var ctrl: ListenableFuture<MediaController>? = null
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        App.refresh(this)
        Engine.attach(Audio.player.audioSessionId)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this); Taste.init(this); Audio.init(this); Flash.init(this); Templates.refresh(this)
        ctrl = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
        val need = ArrayList<String>()
        need.add(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
        need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        perms.launch(need.toTypedArray())
        setContent { DizzApp() }
    }

    override fun onStop() { Cfg.save(); Taste.save(); super.onStop() }
    override fun onDestroy() { ctrl?.let { MediaController.releaseFuture(it) }; super.onDestroy() }
}

@Composable
fun DizzApp() {
    var screen by remember { mutableStateOf("lib") }
    val view = LocalView.current
    val keepOn = screen == "player" || (Cfg.flashOn && Cfg.flashMode != 0 && App.playing)
    SideEffect { view.keepScreenOn = keepOn }
    BackHandler(screen != "lib") {
        screen = when (screen) { "edit" -> "lyrics"; "lyrics" -> "player"; else -> "lib" }
    }
    val ac by animateColorAsState(Pal.accent(), tween(700), label = "acc")
    LaunchedEffect(Look.hueT, Look.satT) { while (Look.moveToward()) { withFrameNanos { } } }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = ac, onPrimary = Color.White, background = Bg, surface = Bg,
            secondaryContainer = Pal.container(), onSecondaryContainer = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color.Transparent, contentColor = Color.White) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Pal.bgTop(), Pal.bgBottom())))) {
                when (screen) {
                    "lib" -> LibraryScreen { screen = it }
                    "player" -> PlayerScreen { screen = it }
                    "lyrics" -> LyricsScreen { screen = it }
                    "edit" -> EditScreen { screen = it }
                    else -> SettingsScreen { screen = it }
                }
                if (screen != "player") ScreenFlashOverlay()   // на экране плеера вспышка рисуется позади интерфейса
            }
        }
    }
}

// ---------- общие элементы ----------

fun Modifier.glass(r: Dp = 20.dp, a: Float = 0.07f): Modifier =
    this.clip(RoundedCornerShape(r)).background(Color.White.copy(alpha = a))
        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(r))

@Composable
fun RoundIcon(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun Pill(s: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.10f)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) { Text(s, fontSize = 13.sp) }
}

@Composable
fun PlayButton(size: Dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(acc, hueShift(acc, 50f)))).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(if (App.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(size / 2), tint = Color.White)
    }
}

@Composable
fun Avatar(t: Track, cur: Boolean, size: Dp = 48.dp) {
    val ctx = LocalContext.current
    val th by produceState<ImageBitmap?>(null, t.id) { value = withContext(Dispatchers.IO) { Covers.thumb(ctx, t)?.asImageBitmap() } }
    val img = if (cur) (Look.cover ?: th) else th
    val h = ((t.title.hashCode() and 0x7fffffff) % 360).toFloat()
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size / 3.5f))
            .background(Brush.linearGradient(listOf(Color.hsv(h, 0.55f, 0.95f), Color.hsv((h + 50f) % 360f, 0.75f, 0.55f)))),
        contentAlignment = Alignment.Center
    ) {
        if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(t.title.take(1).uppercase(), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
    }
}

@Composable
fun Chips(items: List<String>, sel: Int, on: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s -> FilterChip(selected = i == sel, onClick = { on(i) }, label = { Text(s) }) }
    }
}

@Composable
fun Lt(s: String, size: Int, a: Float, bold: Boolean = false) {
    Text(
        s, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        color = Color.White.copy(alpha = a), textAlign = TextAlign.Center, maxLines = 2,
        style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 10f)),
        modifier = Modifier.padding(vertical = 2.dp)
    )
}

// ---------- анимированный текст ----------

/** Доля заполнения строки: от метки строки до следующей (с небольшим запасом до конца). */
fun lineProgress(lines: List<LrcLine>, i: Int, pos: Long): Float {
    val c = lines.getOrNull(i) ?: return 0f
    val n = lines.getOrNull(i + 1)
    val span = ((n?.t ?: (c.t + 4000L)) - c.t).coerceIn(700L, 8000L) * 0.92f
    return ((pos - c.t) / span).coerceIn(0f, 1f)
}

/**
 * Караоке-заливка: тусклый текст, поверх которого плавно, пиксель за пикселем, слева направо
 * проявляется яркий. Если строка переносится, заливка идёт по строкам подряд.
 * progress читается только в фазе рисования — перекомпоновки на каждый кадр нет.
 */
@Composable
fun KaraokeText(text: String, progress: () -> Float, sizeSp: Float, center: Boolean, modifier: Modifier = Modifier) {
    val tm = rememberTextMeasurer()
    val dens = LocalDensity.current
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val maxW = constraints.maxWidth
        val style = TextStyle(
            fontSize = sizeSp.sp, fontWeight = FontWeight.Bold, lineHeight = (sizeSp * 1.25f).sp,
            textAlign = if (center) TextAlign.Center else TextAlign.Start
        )
        val layout = remember(text, maxW, sizeSp, center) { tm.measure(text, style, constraints = Constraints(maxWidth = maxW)) }
        val hDp = with(dens) { layout.size.height.toDp() }
        Canvas(Modifier.fillMaxWidth().height(hDp)) {
            drawText(layout, color = Color.White.copy(alpha = 0.38f), shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 3f), 10f))
            val n = layout.lineCount
            var total = 0f
            for (i in 0 until n) total += layout.getLineRight(i) - layout.getLineLeft(i)
            var left = progress().coerceIn(0f, 1f) * total
            val glow = Shadow(Pal.accent().copy(alpha = 0.85f), Offset.Zero, 20f)
            for (i in 0 until n) {
                val l = layout.getLineLeft(i)
                val r = layout.getLineRight(i)
                val w = max(1f, r - l)
                val frac = (left / w).coerceIn(0f, 1f)
                left -= w
                if (frac <= 0f) continue
                val feather = 0.07f
                val brush = if (frac >= 1f) SolidColor(Color.White)
                else Brush.horizontalGradient(0f to Color.White, frac to Color.White, min(1f, frac + feather) to Color.Transparent, startX = l, endX = r)
                val clipR = if (frac >= 1f) size.width else l + w * min(1f, frac + feather)
                clipRect(0f, layout.getLineTop(i), clipR, layout.getLineBottom(i)) {
                    drawText(layout, brush = brush, shadow = glow)
                }
            }
        }
    }
}

@Composable
fun LyricsBlock(lines: List<LrcLine>, synced: Boolean, idx: Int, posS: State<Long>, open: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = open).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        when {
            lines.isEmpty() -> Lt("Текста пока нет — нажмите, чтобы найти или написать", 14, 0.6f)
            !synced -> Lt("Текст без меток времени — «Правка» → «Вставить время»", 14, 0.7f)
            else -> AnimatedContent(
                targetState = idx,
                transitionSpec = {
                    (slideInVertically(tween(380)) { it / 3 } + fadeIn(tween(380))) togetherWith
                        (slideOutVertically(tween(260)) { -it / 3 } + fadeOut(tween(200)))
                },
                label = "line"
            ) { i ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Lt(lines.getOrNull(i - 1)?.text.orEmpty().ifBlank { " " }, 15, 0.45f)
                    val cur = lines.getOrNull(i)
                    if (cur != null) KaraokeText(cur.text.ifBlank { "♪" }, { lineProgress(lines, i, posS.value) }, 26f, true)
                    else Lt(" ", 26, 0f)
                    Lt(lines.getOrNull(i + 1)?.text.orEmpty().ifBlank { " " }, 16, 0.55f)
                }
            }
        }
    }
}

/** Позиция воспроизведения, обновляется раз в кадр и читается только там, где нужна. */
@Composable
fun rememberPos(): State<Long> = produceState(0L) {
    var last = 0L
    while (true) {
        withFrameNanos { n ->
            if (n - last >= 16_000_000L) { last = n; value = Audio.player.currentPosition }
        }
    }
}

@Composable
fun SeekRow(posS: State<Long>, dur: Long, onSeek: (Long) -> Unit) {
    val pos = posS.value
    var drag by remember { mutableStateOf<Float?>(null) }
    Slider(
        value = drag ?: (pos.toFloat() / dur).coerceIn(0f, 1f),
        onValueChange = { drag = it },
        onValueChangeFinished = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = acc, inactiveTrackColor = Color.White.copy(alpha = 0.2f))
    )
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
        Text(Lyrics.fmt(pos).take(5), fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.weight(1f))
        Text(Lyrics.fmt(dur).take(5), fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
    }
}

// ---------- библиотека ----------

@Composable
fun LibraryScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var job by remember { mutableStateOf<Job?>(null) }
    val list = remember(App.tracks, q) {
        if (q.isBlank()) App.tracks else App.tracks.filter { (it.title + " " + it.artist).contains(q, true) }
    }

    fun startBatch() {
        job = scope.launch(Dispatchers.IO) {
            val todo = App.tracks.filter { it.id !in App.lyricIds }
            var ok = 0
            for ((i, t) in todo.withIndex()) {
                ensureActive()
                status = "Ищу ${i + 1}/${todo.size}: ${t.title}"
                var text = try { Net.lrclib(t) } catch (e: Exception) { null }
                if (text == null && Cfg.aiInBatch && Cfg.apiKey.isNotBlank()) {
                    status = "ИИ слушает ${i + 1}/${todo.size}: ${t.title}"
                    text = try { Net.transcribe(ctx, t) } catch (e: Exception) { null }
                }
                if (text != null) { Lyrics.save(ctx, t.id, text); ok++ }
            }
            status = "Готово: найдено $ok из ${todo.size}"
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "DizzPlayer", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                    style = TextStyle(brush = Brush.horizontalGradient(listOf(acc, hueShift(acc, 60f))))
                )
                Text("${App.tracks.size} треков · ${App.lyricIds.size} с текстом", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f))
            }
            RoundIcon({ go("settings") }) { Icon(Icons.Default.Settings, null) }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(26.dp))
                .background(Brush.horizontalGradient(listOf(Pal.primary(), hueShift(Pal.primary(), 40f))))
                .clickable { Wave.start(ctx); if (App.waveOn) go("player") }
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Моя волна", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Pal.onPrimary())
                Text(
                    if (Wave.status.isNotEmpty()) Wave.status else "Музыка, которая подстраивается под тебя",
                    fontSize = 12.sp, color = Pal.onPrimary().copy(alpha = 0.75f)
                )
            }
            Icon(Icons.Default.PlayArrow, null, Modifier.size(40.dp), tint = Pal.onPrimary())
        }
        OutlinedTextField(
            q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), singleLine = true,
            placeholder = { Text("Поиск по трекам") }, shape = RoundedCornerShape(28.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.White.copy(alpha = 0.12f), focusedBorderColor = acc,
                unfocusedContainerColor = Color.White.copy(alpha = 0.05f), focusedContainerColor = Color.White.copy(alpha = 0.07f)
            )
        )
        Row(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            if (job?.isActive == true) Button({ job?.cancel(); status = "Остановлено" }, shape = RoundedCornerShape(24.dp)) { Text("Стоп") }
            else Button({ startBatch() }, shape = RoundedCornerShape(24.dp)) { Text("Найти тексты для всех") }
            Spacer(Modifier.width(10.dp))
            Text(status, fontSize = 12.sp, maxLines = 2, color = Color.White.copy(alpha = 0.5f))
        }
        if (App.tracks.isEmpty()) Text("Треков не найдено. Дайте доступ к аудио в настройках телефона.", Modifier.padding(20.dp), color = Color.Gray)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 8.dp)) {
            itemsIndexed(list, key = { _, t -> t.id }) { i, t ->
                val cur = App.current?.id == t.id
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp).clip(RoundedCornerShape(16.dp))
                        .background(if (cur) acc.copy(alpha = 0.14f) else Color.Transparent)
                        .clickable { App.play(list, i); go("player") }.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(t, cur)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title, maxLines = 1, fontWeight = FontWeight.Medium, color = if (cur) acc else Color.White)
                        Text(t.artist.ifBlank { "Неизвестный исполнитель" }, fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f), maxLines = 1)
                    }
                    if (t.id in App.lyricIds) Text("♪", color = acc, fontSize = 18.sp, modifier = Modifier.padding(end = 6.dp))
                }
            }
        }
        App.current?.let { t ->
            Row(
                Modifier.fillMaxWidth().padding(12.dp).glass(24.dp, 0.10f).clickable { go("player") }.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(t, true, 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, maxLines = 1, fontWeight = FontWeight.Medium)
                    Text(t.artist.ifBlank { "—" }, fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f), maxLines = 1)
                }
                PlayButton(44.dp) { if (App.playing) Audio.player.pause() else Audio.player.play() }
            }
        }
    }
}

// ---------- плеер ----------

private fun mmss(ms: Long): String {
    val sec = max(0L, ms) / 1000L
    return "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
}

private fun speedLabel(v: Float) = v.toString().removeSuffix(".0") + "x"

@Composable
fun rememberScene(): AveeScene? {
    val ctx = LocalContext.current
    val ti = Cfg.style - STYLES.size
    val name = if (ti >= 0) Templates.names.getOrNull(ti) else null
    return remember(name) { name?.let { Templates.scene(ctx, it) } }
}

/** Единые часы кадров: фон-переливы, визуализация и волна прогресса. Шаблоны ~33 к/с, остальное ~60 к/с. */
@Composable
fun ClockLoop(tpl: Boolean) {
    LaunchedEffect(tpl) {
        var last = 0L
        val gap = if (tpl) 30_000_000L else 15_000_000L
        while (true) {
            withFrameNanos { n ->
                if (n - last >= gap) {
                    val dt = if (last == 0L) 0.016f else ((n - last) / 1e9f).coerceAtMost(0.1f)
                    last = n
                    Engine.step(dt)
                    Clock.t = n
                }
            }
        }
    }
}

@Composable
fun VizView(modifier: Modifier, scene: AveeScene?, opaque: Boolean = true) {
    Canvas(modifier) {
        val t = Clock.t / 1_000_000_000f
        var drawn = false
        val sc = scene
        if (sc != null && sc.ok) {
            val p = Audio.player
            val inf = Info(p.currentPosition, p.duration.coerceAtLeast(0L), App.current?.title ?: "", App.current?.artist ?: "")
            drawIntoCanvas { c ->
                try {
                    sc.draw(c.nativeCanvas, size.width, size.height, inf, Cfg.vizQuality, Cfg.vizTrails, opaque)
                    drawn = true
                } catch (e: Throwable) {
                    sc.ok = false
                    Templates.lastError = "Ошибка шаблона: " + (e.message ?: e.javaClass.simpleName)
                }
            }
        }
        if (!drawn) drawViz(t, opaque)
    }
}

/** Фон плеера: размытые переливы в цветах темы, поверх них чёткая (слегка смягчённая) визуализация. */
@Composable
fun PlayerBackdrop() {
    val scene = rememberScene()
    ClockLoop(scene != null)
    val b = Cfg.blurDp
    Box(Modifier.fillMaxSize().then(if (b >= 1f) Modifier.blur(b.dp) else Modifier)) {
        AuroraBg(Modifier.fillMaxSize())
    }
    FrostOverlay(Modifier.fillMaxSize())
    if (Cfg.vizBg) {
        val vb = Cfg.vizBlurDp
        Box(Modifier.fillMaxSize().then(if (vb >= 1f) Modifier.blur(vb.dp) else Modifier)) {
            VizView(Modifier.fillMaxSize().graphicsLayer { alpha = Cfg.vizAlpha }, scene, false)
        }
    }
}

@Composable
fun SmallIcon(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(48.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun RoundBtn(size: Dp, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(size).clip(CircleShape).background(Pal.container()).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun BigPlay(onClick: () -> Unit) {
    Box(
        Modifier.size(width = 116.dp, height = 88.dp).clip(RoundedCornerShape(32.dp)).background(Pal.primary()).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(if (App.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(42.dp), tint = Pal.onPrimary())
    }
}

/** Профиль «громкости» трека для полосы времени: стабильный для каждого трека, похож на волновую форму. */
private fun seekProfile(seed: Long, n: Int): FloatArray {
    val r = java.util.Random(seed * 7919L + 17L)
    val ph0 = r.nextFloat() * 6.28f
    val ph1 = r.nextFloat() * 6.28f
    val raw = FloatArray(n) { i ->
        val x = i.toFloat() / n
        val env = 0.55f + 0.25f * sin(x * 6.28f * 1.3f + ph0) + 0.2f * sin(x * 6.28f * 3.1f + ph1)
        (0.55f * (0.25f + 0.75f * r.nextFloat()) + 0.45f * env).coerceIn(0.1f, 1f)
    }
    return FloatArray(n) { i ->
        val a = raw[(i - 1).coerceAtLeast(0)]
        val b = raw[i]
        val c = raw[(i + 1).coerceAtMost(n - 1)]
        0.25f * a + 0.5f * b + 0.25f * c
    }
}

/**
 * Полоса времени из зеркальных столбиков (вверх и вниз от центральной линии).
 * Пройденная часть яркая и «танцует» под живой спектр, непройденная тусклая; у головки — всплеск на бите.
 */
@Composable
fun BarSeek(posS: State<Long>, dur: Long, trackId: Long, onSeek: (Long) -> Unit) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val prof = remember(trackId) { seekProfile(trackId, 160) }
    Canvas(
        Modifier.fillMaxWidth().height(56.dp)
            .pointerInput(dur) { detectTapGestures { o -> onSeek((o.x / size.width * dur).toLong().coerceIn(0L, dur)) } }
            .pointerInput(dur) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
                    onDragCancel = { drag = null },
                    onHorizontalDrag = { ch, _ -> drag = (ch.position.x / size.width).coerceIn(0f, 1f) }
                )
            }
    ) {
        val t = Clock.t / 1_000_000_000f
        val frac = drag ?: (posS.value.toFloat() / dur).coerceIn(0f, 1f)
        val w = size.width
        val cy = size.height / 2f
        val bw = 3.5.dp.toPx()
        val gap = 2.5.dp.toPx()
        val n = max(12, ((w + gap) / (bw + gap)).toInt())
        val step = w / n
        val maxHalf = size.height / 2f - 2.dp.toPx()
        val playedN = frac * n
        val sh = Engine.shown
        val pulse = Engine.pulse * Cfg.shimmer
        val dim = Pal.accent().copy(alpha = 0.30f)
        for (i in 0 until n) {
            val f = i / (n - 1f)
            val base = prof[(f * (prof.size - 1)).toInt().coerceIn(0, prof.size - 1)]
            val played = i + 0.5f <= playedN
            var v = 0.14f + 0.32f * base
            if (played) {
                // спектр растягиваем на всю пройденную часть, чтобы она всегда «жила»
                val bin = ((i / max(1f, playedN - 1f)) * (Engine.N - 1)).toInt().coerceIn(0, Engine.N - 1)
                v += 0.62f * min(1.1f, sh[bin])
            }
            v += 0.35f * pulse * (1f - min(1f, abs(i + 0.5f - playedN) / 4f))
            val hh = (maxHalf * v).coerceIn(bw / 2f, maxHalf)
            val x = step * (i + 0.5f)
            val col = if (played) pal(f, t) else dim
            if (played) drawLine(col.copy(alpha = 0.18f), Offset(x, cy - hh), Offset(x, cy + hh), bw * 2.2f, StrokeCap.Round)
            drawLine(col, Offset(x, cy - hh), Offset(x, cy + hh), bw, StrokeCap.Round)
        }
        val xp = frac * w
        drawRoundRect(
            Color.White, Offset(xp - 1.5.dp.toPx(), cy - maxHalf - 2.dp.toPx()),
            Size(3.dp.toPx(), 2f * maxHalf + 4.dp.toPx()), CornerRadius(1.5.dp.toPx())
        )
    }
}

/** Полоса перемотки = визуализация: пройденная часть — волна, амплитуда которой следует за спектром, остальное — прямая линия. */
@Composable
fun WaveSeek(posS: State<Long>, dur: Long, onSeek: (Long) -> Unit) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val path = remember { Path() }
    Canvas(
        Modifier.fillMaxWidth().height(48.dp)
            .pointerInput(dur) { detectTapGestures { o -> onSeek((o.x / size.width * dur).toLong().coerceIn(0L, dur)) } }
            .pointerInput(dur) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
                    onDragCancel = { drag = null },
                    onHorizontalDrag = { ch, _ -> drag = (ch.position.x / size.width).coerceIn(0f, 1f) }
                )
            }
    ) {
        val t = Clock.t / 1_000_000_000f
        val frac = drag ?: (posS.value.toFloat() / dur).coerceIn(0f, 1f)
        val w = size.width
        val cy = size.height / 2f
        val xp = frac * w
        val a = Pal.accent()
        val track = 4.dp.toPx()
        drawLine(a.copy(alpha = 0.38f), Offset(xp, cy), Offset(w, cy), track, StrokeCap.Round)
        path.reset()
        val lam = 40.dp.toPx()
        val baseAmp = 2.5.dp.toPx()
        val maxAmp = 11.dp.toPx()
        val ph = t * 4.5f
        val sh = Engine.shown
        val step = 3.dp.toPx()
        var x = 0f
        var first = true
        while (true) {
            val bin = ((min(x, w) / w) * (Engine.N - 1)).toInt().coerceIn(0, Engine.N - 1)
            val amp = (baseAmp + maxAmp * sh[bin]).coerceAtMost(maxAmp * 1.3f)
            val y = cy + amp * sin(2f * PI.toFloat() * x / lam - ph)
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            if (x >= xp) break
            x = min(x + step, xp)
        }
        drawPath(path, a.copy(alpha = 0.22f), style = Stroke(track * 2.6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(path, a, style = Stroke(track * 1.25f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawRoundRect(
            Color.White, Offset(xp - 3.dp.toPx(), cy - 15.dp.toPx()), Size(6.dp.toPx(), 30.dp.toPx()), CornerRadius(3.dp.toPx())
        )
    }
}

@Composable
fun TimeRow(posS: State<Long>, dur: Long) {
    val sec by remember { derivedStateOf { posS.value / 1000L } }
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
        Text(mmss(sec * 1000L), fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.weight(1f))
        Text(mmss(dur), fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
    }
}

/** Настройки оформления: стиль визуализации, фон, блюр, мерцание, тема. Используются в меню плеера и в настройках. */
@Composable
fun StyleControls() {
    Text("Стиль визуализации", fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
    Spacer(Modifier.height(6.dp))
    Chips(STYLES + Templates.names, Cfg.style) { Cfg.style = it }
    Spacer(Modifier.height(8.dp))
    Chips(PALETTES, Cfg.palette) { Cfg.palette = it }
    Text("Полоса времени", fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f), modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
    Chips(listOf("Зеркальные столбики", "Волна"), Cfg.seekStyle) { Cfg.seekStyle = it }
    SwitchRow("Визуализация на фоне", Cfg.vizBg) { Cfg.vizBg = it }
    Sl("Яркость визуализации", Cfg.vizAlpha, 0.1f..1f, "${(Cfg.vizAlpha * 100).toInt()}%") { Cfg.vizAlpha = it }
    Sl("Размытие визуализации", Cfg.vizBlurDp, 0f..30f, if (Cfg.vizBlurDp < 1f) "чётко" else "${Cfg.vizBlurDp.toInt()}") { Cfg.vizBlurDp = it }
    Sl("Положение по высоте", Cfg.vizPos, 0.3f..0.9f, "${(Cfg.vizPos * 100).toInt()}%") { Cfg.vizPos = it }
    Sl("Матовость фона (блюр)", Cfg.blurDp, 0f..60f, if (Cfg.blurDp < 1f) "выкл" else "${Cfg.blurDp.toInt()}") { Cfg.blurDp = it }
    Sl("Мерцание под бит", Cfg.shimmer, 0f..2f, "${(Cfg.shimmer * 100).toInt()}%") { Cfg.shimmer = it }
    Text("Тема", fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f), modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
    Chips(listOf("По обложке", "Свой цвет"), Cfg.themeMode) { Cfg.themeMode = it }
    if (Cfg.themeMode == 1) {
        Sl("Оттенок", Cfg.themeHue, 0f..360f, "${Cfg.themeHue.toInt()}°") { Cfg.themeHue = it }
        Sl("Насыщенность", Cfg.themeSat, 0.2f..1f, "${(Cfg.themeSat * 100).toInt()}%") { Cfg.themeSat = it }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(Pal.primary(), Pal.container(), Pal.bgTop()).forEach { Box(Modifier.size(32.dp).clip(CircleShape).background(it)) }
        }
    }
    if (Templates.lastError.isNotEmpty()) Text(Templates.lastError, fontSize = 12.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun QueueDialog(onDismiss: () -> Unit) {
    val p = Audio.player
    val items = remember { (0 until p.mediaItemCount).map { p.getMediaItemAt(it) } }
    val cur = p.currentMediaItemIndex
    val ls = rememberLazyListState(initialFirstVisibleItemIndex = max(0, cur - 2))
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onDismiss) { Text("Закрыть") } },
        title = { Text("Очередь") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp), state = ls) {
                itemsIndexed(items) { i, m ->
                    Text(
                        (i + 1).toString() + ". " + (m.mediaMetadata.title?.toString() ?: ""), maxLines = 1,
                        color = if (i == cur) acc else Color.White,
                        modifier = Modifier.fillMaxWidth().clickable { p.seekTo(i, 0L); p.play(); onDismiss() }.padding(vertical = 10.dp)
                    )
                }
            }
        }
    )
}

@Composable
fun PlayerScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val p = Audio.player
    val t = App.current
    val posS = rememberPos()
    val dur = (if (p.duration > 0) p.duration else (t?.durMs ?: 1L)).coerceAtLeast(1L)
    val lines = remember(t?.id, App.rev) { t?.let { Lyrics.load(ctx, it.id) }?.let { Lyrics.parse(it) } ?: emptyList() }
    val synced = lines.isNotEmpty() && lines[0].t >= 0
    val idx by remember(lines) { derivedStateOf { if (synced) idxAt(lines, posS.value) else -1 } }
    val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    var showLyrics by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var styleDlg by remember { mutableStateOf(false) }
    var queueDlg by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        PlayerBackdrop()
        ScreenFlashOverlay()   // вспышка позади интерфейса
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val side = minOf(maxWidth - 36.dp, maxHeight * 0.40f)
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SmallIcon({ go("lib") }) { Icon(Icons.Default.KeyboardArrowDown, null, Modifier.size(32.dp)) }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (App.waveOn) "Моя волна" else (t?.album?.ifBlank { "Моя музыка" } ?: "Моя музыка"), maxLines = 1, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("Трек ${p.currentMediaItemIndex + 1} из ${p.mediaItemCount}", fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
                    }
                    Box {
                        SmallIcon({ menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (App.waveOn) DropdownMenuItem(
                                text = { Text("Не нравится — реже такое") },
                                onClick = { menu = false; t?.let { Taste.dislike(it) }; p.seekToNext() }
                            )
                            DropdownMenuItem(text = { Text("Оформление") }, onClick = { menu = false; styleDlg = true })
                            DropdownMenuItem(text = { Text("Текст и правка") }, onClick = { menu = false; go("lyrics") })
                            DropdownMenuItem(text = { Text("Настройки") }, onClick = { menu = false; go("settings") })
                        }
                    }
                }
                Spacer(Modifier.weight(0.5f))
                Box(
                    Modifier.align(Alignment.CenterHorizontally).size(side)
                        .graphicsLayer {
                            @Suppress("UNUSED_VARIABLE") val tick = Clock.t
                            val sc = 1f + 0.012f * Engine.pulse * Cfg.shimmer
                            scaleX = sc; scaleY = sc
                        }
                        .clip(RoundedCornerShape(36.dp)).background(Pal.container())
                ) {
                    Crossfade(showLyrics, label = "cover") { lyr ->
                        if (lyr) {
                            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)).padding(16.dp), contentAlignment = Alignment.Center) {
                                LyricsBlock(lines, synced, idx, posS) { go("lyrics") }
                            }
                        } else {
                            val img = Look.cover
                            if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Box(
                                Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Pal.primary(), Pal.container()))),
                                contentAlignment = Alignment.Center
                            ) { Text(t?.title?.take(1)?.uppercase() ?: "♪", fontSize = 96.sp, fontWeight = FontWeight.Bold, color = Pal.onPrimary()) }
                        }
                    }
                }
                Spacer(Modifier.weight(0.4f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t?.title ?: "", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, lineHeight = 30.sp)
                        val sub = listOfNotNull(t?.artist?.ifBlank { null }, t?.album?.ifBlank { null }).joinToString(" · ")
                        if (sub.isNotEmpty()) Text(sub, fontSize = 15.sp, color = Color.White.copy(alpha = 0.65f), maxLines = 1)
                    }
                    val fav = t != null && t.id in Cfg.favs
                    SmallIcon({
                        if (t != null) Cfg.favs = if (t.id in Cfg.favs) Cfg.favs - t.id else Cfg.favs + t.id
                    }) {
                        Icon(if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, Modifier.size(30.dp), tint = if (fav) Pal.accent() else Color.White)
                    }
                }
                Spacer(Modifier.height(6.dp))
                if (Cfg.seekStyle == 0) BarSeek(posS, dur, t?.id ?: 0L) { p.seekTo(it) } else WaveSeek(posS, dur) { p.seekTo(it) }
                TimeRow(posS, dur)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        SmallIcon({ p.shuffleModeEnabled = !p.shuffleModeEnabled }) {
                            Icon(Icons.Default.Shuffle, null, tint = if (App.shuffle) Pal.accent() else Color.White.copy(alpha = 0.55f))
                        }
                        Box(Modifier.size(5.dp).clip(CircleShape).background(if (App.shuffle) Pal.accent() else Color.Transparent))
                    }
                    RoundBtn(68.dp, { p.seekToPrevious() }) { Icon(Icons.Default.SkipPrevious, null, Modifier.size(32.dp), tint = Pal.primary()) }
                    BigPlay { if (App.playing) p.pause() else p.play() }
                    RoundBtn(68.dp, { p.seekToNext() }) { Icon(Icons.Default.SkipNext, null, Modifier.size(32.dp), tint = Pal.primary()) }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        SmallIcon({ p.repeatMode = when (App.repeat) { 0 -> 2; 2 -> 1; else -> 0 } }) {
                            Icon(
                                if (App.repeat == 1) Icons.Default.RepeatOne else Icons.Default.Repeat, null,
                                tint = if (App.repeat != 0) Pal.accent() else Color.White.copy(alpha = 0.55f)
                            )
                        }
                        Box(Modifier.size(5.dp).clip(CircleShape).background(if (App.repeat != 0) Pal.accent() else Color.Transparent))
                    }
                }
                Spacer(Modifier.weight(0.5f))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.height(48.dp).clip(RoundedCornerShape(24.dp))
                            .border(2.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
                            .clickable {
                                val speeds = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)
                                val i = speeds.indexOfFirst { kotlin.math.abs(it - App.speed) < 0.01f }
                                p.setPlaybackSpeed(speeds[(i + 1) % speeds.size])
                            }
                            .padding(horizontal = 22.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(speedLabel(App.speed), fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.weight(1f))
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        Box(
                            Modifier.size(width = 76.dp, height = 56.dp)
                                .clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp, topEnd = 6.dp, bottomEnd = 6.dp))
                                .background(Pal.container()).clickable { showLyrics = !showLyrics },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.FormatQuote, null, Modifier.size(30.dp), tint = if (showLyrics) Pal.accent() else Color.White) }
                        Box(
                            Modifier.size(width = 76.dp, height = 56.dp)
                                .clip(RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp, topEnd = 24.dp, bottomEnd = 24.dp))
                                .background(Pal.container()).clickable { queueDlg = true },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.QueueMusic, null, Modifier.size(28.dp)) }
                    }
                }
                if (!micOk) Text(
                    "Для визуализации нужно разрешение «Микрофон» (используется только для анализа звука плеера).",
                    fontSize = 11.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        if (styleDlg) AlertDialog(
            onDismissRequest = { styleDlg = false },
            confirmButton = { TextButton({ styleDlg = false }) { Text("Готово") } },
            title = { Text("Оформление") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { StyleControls() } }
        )
        if (queueDlg) QueueDialog { queueDlg = false }
    }
}

// ---------- текст песни ----------

@Composable
fun LyricsScreen(go: (String) -> Unit) {
    val t = App.current
    if (t == null) { Text("Сначала выберите трек", Modifier.padding(24.dp)); return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = Audio.player
    val posS = rememberPos()
    val lines = remember(t.id, App.rev) { Lyrics.load(ctx, t.id)?.let { Lyrics.parse(it) } ?: emptyList() }
    val synced = lines.isNotEmpty() && lines[0].t >= 0
    val idx by remember(lines) { derivedStateOf { if (synced) idxAt(lines, posS.value) else -1 } }
    val ls = rememberLazyListState()
    LaunchedEffect(idx) { if (idx >= 0) ls.animateScrollToItem((idx - 2).coerceAtLeast(0)) }
    var busy by remember { mutableStateOf("") }
    var ask by remember { mutableStateOf<(() -> Unit)?>(null) }

    fun online() {
        scope.launch {
            busy = "Ищу текст в интернете…"
            val r = withContext(Dispatchers.IO) { runCatching { Net.lrclib(t) }.getOrNull() }
            if (r != null) { Lyrics.save(ctx, t.id, r); busy = "Найдено" } else busy = "Не найдено. Попробуйте ИИ-распознавание."
        }
    }
    fun ai() {
        scope.launch {
            busy = "ИИ слушает песню… (до минуты)"
            val r = withContext(Dispatchers.IO) { runCatching { Net.transcribe(ctx, t) } }
            r.onSuccess { Lyrics.save(ctx, t.id, it); busy = "Готово. Проверьте текст и поправьте в «Править»" }
                .onFailure { busy = "Ошибка: ${it.message}" }
        }
    }
    fun guard(a: () -> Unit) { if (lines.isNotEmpty()) ask = a else a() }

    ask?.let { a ->
        AlertDialog(
            onDismissRequest = { ask = null },
            title = { Text("Заменить текущий текст?") },
            text = { Text("Ваши правки будут потеряны.") },
            confirmButton = { TextButton({ ask = null; a() }) { Text("Заменить") } },
            dismissButton = { TextButton({ ask = null }) { Text("Отмена") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon({ go("player") }) { Icon(Icons.Default.ArrowBack, null) }
            Column(Modifier.padding(start = 12.dp)) {
                Text(t.title, maxLines = 1, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(t.artist, maxLines = 1, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
            }
        }
        Row(Modifier.padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Искать") { guard { online() } }
            Pill("ИИ") { guard { ai() } }
            Pill("Править") { go("edit") }
        }
        if (busy.isNotEmpty()) Text(busy, fontSize = 12.sp, color = acc, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
        LazyColumn(state = ls, modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)) {
            if (lines.isEmpty()) item {
                Text("Текста пока нет.\n«Искать» — бесплатная база онлайн, «ИИ» — распознать голос в песне, «Править» — вставить свой.", color = Color.Gray)
            }
            itemsIndexed(lines) { i, l ->
                val cur = i == idx
                val a by animateFloatAsState(if (cur) 1f else if (synced) 0.4f else 0.9f, tween(300), label = "la")
                val sc by animateFloatAsState(if (cur) 1f else 0.86f, tween(300), label = "ls")
                Box(
                    Modifier.fillMaxWidth().clickable(enabled = synced) { p.seekTo(l.t) }.padding(vertical = 8.dp)
                        .graphicsLayer { scaleX = sc; scaleY = sc; alpha = a; transformOrigin = TransformOrigin(0f, 0.5f) }
                ) {
                    if (cur) KaraokeText(l.text.ifBlank { "♪" }, { lineProgress(lines, i, posS.value) }, 24f, false)
                    else Text(l.text.ifBlank { "♪" }, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun stamp(tf: TextFieldValue, pos: Long): TextFieldValue {
    val text = tf.text
    val s = tf.selection.start.coerceIn(0, text.length)
    val ls = text.lastIndexOf('\n', s - 1) + 1
    var le = text.indexOf('\n', ls)
    if (le < 0) le = text.length
    val line = text.substring(ls, le).replace(Regex("^(\\[\\d+:\\d+([.:]\\d+)?])+"), "")
    val ins = "[${Lyrics.fmt(pos)}]$line"
    val res = text.substring(0, ls) + ins + text.substring(le)
    return TextFieldValue(res, TextRange((ls + ins.length + 1).coerceAtMost(res.length)))
}

@Composable
fun EditScreen(go: (String) -> Unit) {
    val t = App.current
    if (t == null) { Text("Сначала выберите трек", Modifier.padding(24.dp)); return }
    val ctx = LocalContext.current
    val p = Audio.player
    val pos by produceState(0L) { while (true) { value = p.currentPosition; delay(50) } }
    var tf by remember { mutableStateOf(TextFieldValue(Lyrics.load(ctx, t.id) ?: "")) }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIcon({ go("lyrics") }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Правка: ${t.title}", Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1, fontWeight = FontWeight.Bold)
            Button({ Lyrics.save(ctx, t.id, tf.text); go("lyrics") }, shape = RoundedCornerShape(24.dp)) { Text("Сохранить") }
        }
        Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            PlayButton(44.dp) { if (App.playing) p.pause() else p.play() }
            Spacer(Modifier.width(12.dp))
            Text(Lyrics.fmt(pos), color = acc, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Pill("Вставить время") { tf = stamp(tf, pos) }
        }
        Text(
            "Формат строки: [мм:сс.хх] слова. Поставьте курсор в строку и нажмите «Вставить время» в момент, когда её поют — курсор перейдёт на следующую строку. Пустой текст = удалить.",
            fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(bottom = 6.dp)
        )
        OutlinedTextField(
            tf, { tf = it }, Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.White.copy(alpha = 0.12f), focusedBorderColor = acc,
                unfocusedContainerColor = Color.White.copy(alpha = 0.05f), focusedContainerColor = Color.White.copy(alpha = 0.07f)
            )
        )
    }
}

// ---------- настройки ----------

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 14.dp).glass(22.dp).padding(16.dp)) {
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = acc)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
fun Sl(label: String, v: Float, r: ClosedFloatingPointRange<Float>, shown: String, set: (Float) -> Unit) {
    Text("$label: $shown", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    Slider(v, set, valueRange = r)
}

@Composable
fun SwitchRow(label: String, v: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(v, set)
    }
}

@Composable
fun SettingsScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var vizMsg by remember { mutableStateOf("") }
    var tasteMsg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            vizMsg = "Импорт…"
            vizMsg = withContext(Dispatchers.IO) {
                try { "Импортировано: " + Templates.import(ctx, uri) } catch (e: Exception) { "Ошибка: " + e.message }
            }
            Templates.refresh(ctx)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIcon({ go("lib") }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Настройки", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
        }
        Section("Оформление плеера") {
            StyleControls()
            SwitchRow("Искать обложки в интернете, если их нет в тегах", Cfg.autoCover) { Cfg.autoCover = it }
            Sl("Чувствительность спектра", Cfg.gain, 0.5f..2.5f, "${(Cfg.gain * 100).toInt()}%") { Cfg.gain = it }
            SwitchRow("Частицы", Cfg.particles) { Cfg.particles = it }
        }
        Section("Шаблоны Avee Player (.viz)") {
            Text(
                "Импортируйте файл .viz — шаблон появится в списке стилей (экран плеера → ⋮ → Оформление). Шаблон рисуется видеокартой в полном разрешении. Поддержаны слои: картинки и маски, столбики спектра, частицы, текст, блюр-свечение (Android 12+), RGB-сплит, зеркало, моушн-блюр.",
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
            )
            Button({ picker.launch(arrayOf("*/*")) }, Modifier.padding(top = 10.dp), shape = RoundedCornerShape(24.dp)) { Text("Импортировать .viz") }
            if (vizMsg.isNotEmpty()) Text(vizMsg, fontSize = 12.sp, color = acc, modifier = Modifier.padding(top = 6.dp))
            Templates.names.forEach { n ->
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(n, Modifier.weight(1f), maxLines = 1)
                    TextButton({ Templates.delete(ctx, n) }) { Text("Удалить") }
                }
            }
            Sl("Детализация (частицы, свечение)", Cfg.vizQuality, 0.2f..1f, "${(Cfg.vizQuality * 100).toInt()}%") { Cfg.vizQuality = it }
            SwitchRow("Шлейф моушн-блюра (нагружает видеокарту)", Cfg.vizTrails) { Cfg.vizTrails = it }
            if (Templates.lastError.isNotEmpty()) Text(Templates.lastError, fontSize = 12.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 6.dp))
        }
        Section("Моя волна") {
            Text(
                "Подбирает треки из твоей музыки по лайкам (сердечко), дослушиваниям и пропускам и со временем лучше угадывает вкус. Данные обучения хранятся только на телефоне.",
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
            )
            Sl("Знакомое ↔ новое", Cfg.waveNovelty, 0f..0.6f, "новых ${(Cfg.waveNovelty * 100).toInt()}%") { Cfg.waveNovelty = it }
            SwitchRow("Добавлять новые треки из интернета (Jamendo)", Cfg.jamendoOn) { Cfg.jamendoOn = it }
            if (Cfg.jamendoOn) {
                OutlinedTextField(
                    Cfg.jamendoId, { Cfg.jamendoId = it.trim() }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                    label = { Text("Jamendo client_id") }
                )
                Text(
                    "Бесплатный ключ: devportal.jamendo.com. Каждый третий трек волны — находка по твоим любимым жанрам; это музыка независимых артистов со свободной лицензией, ИИ-распознавание текста для неё недоступно.",
                    fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(top = 4.dp)
                )
            }
            if (Wave.status.isNotEmpty()) Text(Wave.status, fontSize = 12.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 6.dp))
            Button({ Taste.reset(); tasteMsg = "Обучение сброшено" }, Modifier.padding(top = 10.dp), shape = RoundedCornerShape(24.dp)) { Text("Сбросить обучение волны") }
            if (tasteMsg.isNotEmpty()) Text(tasteMsg, fontSize = 12.sp, color = acc)
        }
        Section("Вспышка под бит") {
            SwitchRow("Включить вспышку", Cfg.flashOn) { Cfg.flashOn = it }
            Chips(listOf("Фонарик", "Экран", "Оба"), Cfg.flashMode) { Cfg.flashMode = it }
            if (Cfg.flashMode != 1 && !Flash.available) Text("Фонарик на этом устройстве не найден", color = Color(0xFFFF6B6B))
            Text("Реагировать на", fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
            Chips(listOf("Бас", "Середина", "Верха", "Всё"), Cfg.flashBand) { Cfg.flashBand = it }
            Sl("Чувствительность к биту", Cfg.flashSens, 0f..1f, "${(Cfg.flashSens * 100).toInt()}%") { Cfg.flashSens = it }
            Sl("Мин. пауза между вспышками", Cfg.flashGap, 100f..600f, "${Cfg.flashGap.toInt()} мс") { Cfg.flashGap = it }
            if (Cfg.flashMode != 0) {
                Text("Вспышка экрана", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
                Sl("Яркость вспышки", Cfg.screenBright, 0.1f..1f, "${(Cfg.screenBright * 100).toInt()}%") { Cfg.screenBright = it }
                Sl("Длительность (затухание)", Cfg.screenLen, 50f..800f, "${Cfg.screenLen.toInt()} мс") { Cfg.screenLen = it }
                Text("Цвет", fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
                ColorPicker()
            }
            if (Cfg.flashMode != 1) {
                Text("Фонарик", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
                Sl("Длина вспышки", Cfg.flashLen, 20f..200f, "${Cfg.flashLen.toInt()} мс") { Cfg.flashLen = it }
                if (Flash.hasStrength) Sl("Яркость фонарика", Cfg.flashBright, 0.1f..1f, "${(Cfg.flashBright * 100).toInt()}%") { Cfg.flashBright = it }
            }
            Button({
                if (Cfg.flashMode != 1) Flash.pulse()
                if (Cfg.flashMode != 0) ScreenFlash.pulse()
            }, Modifier.padding(top = 12.dp), shape = RoundedCornerShape(24.dp)) { Text("Тест вспышки") }
            Text(
                "⚠ Мигающий свет может спровоцировать приступ при фоточувствительной эпилепсии. Яркая вспышка экрана в темноте бьёт по глазам — начните с малой яркости.",
                fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(top = 6.dp)
            )
        }
        Section("ИИ-тексты") {
            Chips(listOf("Groq (бесплатно)", "OpenAI"), Cfg.provider) { Cfg.provider = it }
            OutlinedTextField(
                Cfg.apiKey, { Cfg.apiKey = it.trim() }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                label = { Text("API-ключ") }, visualTransformation = PasswordVisualTransformation()
            )
            OutlinedTextField(
                Cfg.aiLang, { Cfg.aiLang = it.take(5) }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                label = { Text("Язык песен (ru, en… пусто = авто)") }
            )
            SwitchRow("В массовом поиске: если текста нет в базе — распознавать ИИ", Cfg.aiInBatch) { Cfg.aiInBatch = it }
            Text(
                "Ключ Groq: console.groq.com → API Keys. Файл трека до 25 МБ. Распознавание пения может ошибаться — тексты можно поправить в «Править».",
                fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f)
            )
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
fun ColorPicker() {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        FLASH_COLORS.forEachIndexed { i, (_, c) ->
            val sel = Cfg.screenColor == i
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(c)
                    .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color.Gray, CircleShape)
                    .clickable { Cfg.screenColor = i }
            )
        }
    }
    Chips(listOf("Свой оттенок", "Радуга"), Cfg.screenColor - FLASH_COLORS.size) { Cfg.screenColor = FLASH_COLORS.size + it }
    if (Cfg.screenColor == FLASH_COLORS.size) {
        Sl("Оттенок", Cfg.screenHue, 0f..360f, "${Cfg.screenHue.toInt()}°") { Cfg.screenHue = it }
        Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(28.dp).clip(RoundedCornerShape(8.dp)).background(Color.hsv(Cfg.screenHue.coerceIn(0f, 360f), 1f, 1f)))
    } else if (Cfg.screenColor > FLASH_COLORS.size) {
        Text("Цвет меняется на каждый удар", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
    }
}
