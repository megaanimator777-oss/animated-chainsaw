package com.dizz.player

import android.content.Context
import android.os.Build
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.zip.ZipInputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/* ===== Поддержка шаблонов Avee Player (.viz = ZIP: scene.json + картинки) ===== */

class Info(val posMs: Long = 0L, val durMs: Long = 0L, val title: String = "", val artist: String = "")

/** Элемент сцены: обёртка над JSON. Параметры хранятся как {"v": значение, "t": тип, ...}. */
class El(val o: JSONObject) {
    val type: String = o.optString("objType")
    private val c = HashMap<String, Any?>()
    fun has(k: String) = o.has(k)
    fun raw(k: String): Any? {
        if (c.containsKey(k)) return c[k]
        val x = o.opt(k)
        val v = if (x is JSONObject) x.opt("v") else x
        c[k] = v
        return v
    }
    fun nested(k: String): JSONObject? = o.optJSONObject(k)
    fun f(k: String, d: Float = 0f): Float = when (val v = raw(k)) {
        is Number -> v.toFloat()
        is String -> v.toFloatOrNull() ?: d
        else -> d
    }
    fun b(k: String, d: Boolean = false): Boolean = when (val v = raw(k)) {
        is Number -> v.toInt() != 0
        is Boolean -> v
        else -> d
    }
    fun s(k: String, d: String = ""): String = raw(k)?.toString() ?: d
    private val f2c = HashMap<String, Pair<Float, Float>>()
    fun f2(k: String, dx: Float = 0f, dy: Float = 0f): Pair<Float, Float> {
        val cached = f2c[k]
        if (cached != null) return cached
        val p = s(k).trim().split(" ")
        val r = Pair(p.getOrNull(0)?.toFloatOrNull() ?: dx, p.getOrNull(1)?.toFloatOrNull() ?: dy)
        f2c[k] = r
        return r
    }
    fun col(k: String, d: Int = -1): Int = (raw(k) as? Number)?.toInt() ?: d
    private val hc = HashMap<String, Int>()
    fun hsla(k: String, d: Int = -1): Int {
        val cached = hc[k]
        if (cached != null) return cached
        val p = s(k).trim().split(" ").mapNotNull { it.toFloatOrNull() }
        val r = if (p.size < 4) d else hslToArgb(p[0], p[1], p[2], p[3])
        hc[k] = r
        return r
    }
    /** Значения "mvarf": "Constant a b", "Beat a b" (a в покое → b на бите) и т.п. */
    private val mvc = HashMap<String, Triple<String, Float, Float>>()
    fun mv(k: String, def: Float): Float {
        val t = mvc.getOrPut(k) {
            val p = s(k).trim().split(" ")
            val a = p.getOrNull(1)?.toFloatOrNull() ?: def
            Triple(p.getOrNull(0) ?: "", a, p.getOrNull(2)?.toFloatOrNull() ?: a)
        }
        return when (t.first) {
            "Constant", "TrackPosition", "TotalTime", "BeatRandomShake" -> t.second
            "Beat" -> t.second + (t.third - t.second) * Engine.pulse.coerceIn(0f, 1f)
            else -> def
        }
    }
}

private fun nv(o: JSONObject?, k: String): Any? {
    val x = o?.opt(k)
    return if (x is JSONObject) x.opt("v") else x
}
private fun nf(o: JSONObject?, k: String, d: Float): Float = (nv(o, k) as? Number)?.toFloat() ?: d
private fun ni(o: JSONObject?, k: String, d: Int): Int = (nv(o, k) as? Number)?.toInt() ?: d

fun hslToArgb(h: Float, s: Float, l: Float, a: Float): Int {
    val hh = ((h % 1f) + 1f) % 1f
    val q = if (l < 0.5f) l * (1f + s) else l + s - l * s
    val p = 2f * l - q
    fun hue(t0: Float): Float {
        var t = t0
        if (t < 0f) t += 1f
        if (t > 1f) t -= 1f
        return when {
            t < 1f / 6f -> p + (q - p) * 6f * t
            t < 0.5f -> q
            t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
            else -> p
        }
    }
    fun ch(x: Float) = (x * 255f).roundToInt().coerceIn(0, 255)
    return Color.argb(ch(a), ch(hue(hh + 1f / 3f)), ch(hue(hh)), ch(hue(hh - 1f / 3f)))
}

private fun lerpArgb(a: Int, b: Int, u: Float): Int {
    fun m(x: Int, y: Int) = (x + (y - x) * u).roundToInt().coerceIn(0, 255)
    return Color.argb(m(Color.alpha(a), Color.alpha(b)), m(Color.red(a), Color.red(b)), m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b)))
}

private fun mulArgb(a: Int, b: Int): Int =
    Color.argb(Color.alpha(a) * Color.alpha(b) / 255, Color.red(a) * Color.red(b) / 255, Color.green(a) * Color.green(b) / 255, Color.blue(a) * Color.blue(b) / 255)

/** Умножает каналы картинки на цвет (окраска), не закрашивая прозрачные места. */
private fun modulate(c: Int): ColorMatrixColorFilter = ColorMatrixColorFilter(
    ColorMatrix(
        floatArrayOf(
            Color.red(c) / 255f, 0f, 0f, 0f, 0f,
            0f, Color.green(c) / 255f, 0f, 0f, 0f,
            0f, 0f, Color.blue(c) / 255f, 0f, 0f,
            0f, 0f, 0f, Color.alpha(c) / 255f, 0f
        )
    )
)

private fun xfer(mode: String): PorterDuffXfermode? = when (mode) {
    "Add", "AddAlpha" -> PorterDuffXfermode(PorterDuff.Mode.ADD)
    "Screen" -> PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    else -> null
}

private fun bp(mode: String, alpha: Float = 1f, tint: Int = -1): Paint {
    val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    p.xfermode = xfer(mode)
    p.alpha = (alpha * 255f).toInt().coerceIn(0, 255)
    if (tint != -1) p.colorFilter = modulate(tint)
    return p
}

private fun fmtTime(ms: Long): String {
    val s = max(0L, ms) / 1000
    return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
}

private fun solid(c: Int): Bitmap {
    val b = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888)
    b.eraseColor(c)
    return b
}

private fun radial(size: Int, f: (Float) -> Float): Bitmap {
    val px = IntArray(size * size)
    val c = (size - 1) / 2f
    for (y in 0 until size) for (x in 0 until size) {
        val d = hypot(x - c, y - c) / c
        px[y * size + x] = Color.argb((f(d).coerceIn(0f, 1f) * 255f).toInt(), 255, 255, 255)
    }
    val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    b.setPixels(px, 0, size, 0, 0, size, size)
    return b
}

/** Встроенные ресурсы Avee ("internalres:...") рисуем сами. */
private fun internalRes(name: String): Bitmap = when {
    name == "white" -> solid(Color.WHITE)
    name == "black" -> solid(Color.BLACK)
    name == "transparent" -> solid(Color.TRANSPARENT)
    name.contains("vignette") || name.contains("inv") -> radial(128) { d -> ((d - 0.45f) / 0.65f).pow(1.5f) }
    name.contains("rainbow") -> {
        val b = Bitmap.createBitmap(128, 8, Bitmap.Config.ARGB_8888)
        val p = Paint()
        p.shader = LinearGradient(0f, 0f, 128f, 0f, IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }, null, Shader.TileMode.CLAMP)
        Canvas(b).drawRect(0f, 0f, 128f, 8f, p)
        b
    }
    name.contains("sharp") || name.contains("w_a") -> radial(128) { d -> if (d < 0.85f) 1f else (1f - d) / 0.15f }
    else -> radial(128) { d -> (1f - d).pow(1.7f) }
}

class Prov(val e: El) {
    val out = FloatArray(max(2, min(512, e.f("sampleOutCount", 64f).toInt())))
}

private class Pt(var x: Float, var y: Float, var vx: Float, var vy: Float, var age: Float, val life: Float, val size: Float)
private class PS {
    val l = ArrayList<Pt>()
    var acc = 0f
    var last = 0L
    var frame = -1
    var filters: Array<ColorMatrixColorFilter>? = null
}

/**
 * Сцена Avee рисуется НАПРЯМУЮ на аппаратный (GPU) холст в полном разрешении:
 * композиции — это вложенные вызовы рисования, а не битмапы. Слои (saveLayer) создаются только там,
 * где они нужны: маски, окраска, аддитивное наложение. Цели блюра/зеркала записываются один раз (RenderNode).
 */
class AveeScene(private val dir: File) {
    @Volatile var ok = true
    private val comps: List<List<El>>
    private val provs = ArrayList<Prov>()
    private var W = 1080f
    private var H = 1920f
    private var frame = 0
    private var info = Info()
    private var quality = 0.7f
    private var trails = false
    private var motionDepth = 0
    private var lastBeat = -1
    private var shake = 0f
    private val local = HashMap<String, Bitmap?>()
    private val internalBmps = HashMap<String, Bitmap>()
    private val ps = HashMap<El, PS>()
    private val fonts = HashMap<String, Typeface?>()
    private val nodes = HashMap<String, Any>()
    private val sigmas = HashMap<String, Float>()
    private val filt = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        val root = JSONObject(File(dir, "scene.json").readText())
        val arr = root.getJSONArray("compositions")
        val list = ArrayList<List<El>>()
        for (i in 0 until arr.length()) {
            val els = arr.getJSONObject(i).optJSONArray("elements")
            val l = ArrayList<El>()
            if (els != null) for (j in 0 until els.length()) l.add(El(els.getJSONObject(j)))
            list.add(l)
        }
        comps = list
        for (e in comps.getOrElse(0) { emptyList() }) if (e.type == "AudioProvider") provs.add(Prov(e))
        if (provs.isEmpty()) for (c in comps) for (e in c) if (e.type == "AudioProvider") provs.add(Prov(e))
    }

    /** Рисует один кадр шаблона. Вызывать на главном потоке из draw-фазы Compose. */
    fun draw(cv: Canvas, w: Float, h: Float, inf: Info, q: Float, tr: Boolean, opaque: Boolean = true) {
        W = w; H = h; info = inf; quality = q.coerceIn(0.2f, 1f); trails = tr
        frame++
        for (p in provs) updateProv(p)
        if (Engine.beatCount != lastBeat) { lastBeat = Engine.beatCount; shake = Random.nextFloat() * 6.2832f }
        motionDepth = 0
        if (opaque) cv.drawColor(Color.BLACK)
        drawComp(cv, 0, HashSet())
    }

    private fun updateProv(p: Prov) {
        val e = p.e
        val n = p.out.size
        val lo = max(e.f("lowerHz", 20f), 20f)
        val hi = max(e.f("higherHz", 5000f), lo + 1f)
        val lin = e.f("hzLinearFactor", 1f).coerceIn(0f, 1f)
        val mult = e.f("outputMultiplier", 1f)
        val mirror = e.b("mirrorSamples")
        val rel = 0.25f / (1f + e.f("smooth", 0.5f))
        for (k in 0 until n) {
            var fr = if (n > 1) k.toFloat() / (n - 1) else 0f
            if (mirror) fr = abs(2f * fr - 1f)
            val flin = lo + (hi - lo) * fr
            val flog = lo * (hi / lo).pow(fr)
            val tgt = (Engine.magAt(flog + (flin - flog) * lin) * mult).coerceIn(0f, 4f)
            val cur = p.out[k]
            p.out[k] = if (tgt > cur) cur + (tgt - cur) * 0.6f else cur + (tgt - cur) * rel
        }
    }

    // ---------- ресурсы ----------

    private fun decode(f: File): Bitmap? {
        if (!f.exists()) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 2048 || o.outHeight / s > 2048) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeFile(f.path, o2)
    }

    private fun bitmapFor(name: String): Bitmap? {
        if (name.startsWith("internalres:")) return internalBmps.getOrPut(name) { internalRes(name.substring(12)) }
        if (name.startsWith("local:")) {
            if (local.containsKey(name)) return local[name]
            val b = try { decode(File(dir, name.substring(6))) } catch (e: Exception) { null }
            local[name] = b
            return b
        }
        return null
    }

    private fun compIndex(name: String): Int? =
        if (name.startsWith("composition:")) name.substring(12).toIntOrNull() else null

    /** Рисует композицию или картинку (для масок/целей эффектов) в пространстве экрана. */
    private fun drawTarget(cv: Canvas, name: String, stack: HashSet<Int>) {
        val ci = compIndex(name)
        if (ci != null) { drawComp(cv, ci, stack); return }
        val b = bitmapFor(name) ?: return
        cv.drawBitmap(b, null, RectF(0f, 0f, W, H), filt)
    }

    // ---------- обход ----------

    private fun drawComp(cv: Canvas, i: Int, stack: HashSet<Int>) {
        if (i !in comps.indices || stack.size > 24 || !stack.add(i)) return
        try {
            for (e in comps[i]) {
                val sc = cv.save()
                try { drawEl(cv, e, stack) } catch (ex: Exception) { }
                cv.restoreToCount(sc)
            }
        } finally {
            stack.remove(i)
        }
    }

    private fun drawEl(cv: Canvas, e: El, stack: HashSet<Int>) {
        if (e.has("visible") && !e.b("visible", true)) return
        when (e.type) {
            "Image" -> image(cv, e, stack)
            "Bars" -> bars(cv, e)
            "Particles" -> particles(cv, e)
            "Text" -> text(cv, e)
            "BlurEffect" -> blur(cv, e, stack)
            "MotionBlurEffect" -> motion(cv, e, stack)
            "RgbSplitEffect" -> rgb(cv, e, stack)
            "MirrorEffect" -> mirror(cv, e, stack)
            "FOV" -> fov(cv, e, stack)
        }
    }

    // ---------- Image ----------

    /** [bl, bt, bw, bh, l, t, dw, dh, cx, cy]: прямоугольник-рамка и вписанная в неё картинка. */
    private fun fit(e: El, ar: Float): FloatArray? {
        val (px, py) = e.f2("position", 0.5f, 0.5f)
        val (sx, sy) = e.f2("scale", 1f, 1f)
        val (ax, ay) = e.f2("alignmentPosition", 0.5f, 0.5f)
        val bw = abs(sx) * W
        val bh = abs(sy) * H
        if (bw < 1f || bh < 1f) return null
        val crop = e.b("keepAspectRatioAndCropToFit")
        val keep = e.b("keepAspectRatio", true)
        var dw = bw
        var dh = bh
        if (crop) { if (bw / bh > ar) dh = bw / ar else dw = bh * ar }
        else if (keep) { if (bw / bh > ar) dw = bh * ar else dh = bw / ar }
        val cx = px * W
        val cy = py * H
        val bl = cx - ax * bw
        val bt = cy - ay * bh
        return floatArrayOf(bl, bt, bw, bh, bl + (bw - dw) / 2f, bt + (bh - dh) / 2f, dw, dh, cx, cy)
    }

    private fun drawBmp(cv: Canvas, e: El, g: FloatArray, bmp: Bitmap, paint: Paint) {
        cv.save()
        val rot = e.f("rotation")
        if (rot != 0f) cv.rotate(rot, g[8], g[9])
        if (e.b("keepAspectRatioAndCropToFit")) cv.clipRect(g[0], g[1], g[0] + g[2], g[1] + g[3])
        if (e.s("Shape") == "Circle") {
            val p = Path()
            p.addOval(RectF(g[4], g[5], g[4] + g[6], g[5] + g[7]), Path.Direction.CW)
            cv.clipPath(p)
        }
        cv.drawBitmap(bmp, null, RectF(g[4], g[5], g[4] + g[6], g[5] + g[7]), paint)
        cv.restore()
    }

    private fun inlineComp(cv: Canvas, e: El, g: FloatArray, ci: Int, stack: HashSet<Int>) {
        cv.save()
        val rot = e.f("rotation")
        if (rot != 0f) cv.rotate(rot, g[8], g[9])
        if (e.b("keepAspectRatioAndCropToFit")) cv.clipRect(g[0], g[1], g[0] + g[2], g[1] + g[3])
        if (e.s("Shape") == "Circle") {
            val p = Path()
            p.addOval(RectF(g[4], g[5], g[4] + g[6], g[5] + g[7]), Path.Direction.CW)
            cv.clipPath(p)
        }
        cv.translate(g[4], g[5])
        cv.scale(g[6] / W, g[7] / H)
        drawComp(cv, ci, stack)
        cv.restore()
    }

    private fun tintPaint(tint: Int): Paint {
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        if (tint != -1) p.colorFilter = modulate(tint)
        return p
    }

    private fun content(cv: Canvas, e: El, g: FloatArray, bmp: Bitmap?, ci: Int?, tint: Int, stack: HashSet<Int>) {
        if (bmp != null) { drawBmp(cv, e, g, bmp, tintPaint(tint)); return }
        if (ci == null) return
        if (tint != -1) {
            cv.saveLayer(null, tintPaint(tint))
            inlineComp(cv, e, g, ci, stack)
            cv.restore()
        } else inlineComp(cv, e, g, ci, stack)
    }

    private fun image(cv: Canvas, e: El, stack: HashSet<Int>) {
        val name = e.s("customImage")
        if (name.isEmpty()) return
        val ci = compIndex(name)
        val bmp = if (ci == null) bitmapFor(name) else null
        if (ci == null && bmp == null) return
        val g = fit(e, if (bmp != null) bmp.width.toFloat() / bmp.height else W / H) ?: return
        val alpha = e.f("opacityStrength", 1f).coerceIn(0f, 1f)
        val tint = e.hsla("Color")
        val blend = e.s("blendMode")
        val maskName = e.s("MaskImage")
        if (maskName.isNotEmpty()) {
            // слой элемента -> содержимое -> маска (DST_IN / DST_OUT) -> слой накладывается с режимом элемента
            cv.saveLayer(null, bp(blend, alpha, -1))
            content(cv, e, g, bmp, ci, tint, stack)
            val mp = Paint()
            mp.xfermode = PorterDuffXfermode(if (e.s("maskMode").startsWith("Inverted")) PorterDuff.Mode.DST_OUT else PorterDuff.Mode.DST_IN)
            cv.saveLayer(null, mp)
            drawTarget(cv, maskName, stack)
            cv.restore()
            cv.restore()
            return
        }
        if (bmp != null) { drawBmp(cv, e, g, bmp, bp(blend, alpha, tint)); return }
        if (ci == null) return
        val special = tint != -1 || alpha < 1f || blend == "Add" || blend == "AddAlpha" || blend == "Screen"
        if (special) {
            val bounds = if (e.f("rotation") == 0f) RectF(g[4], g[5], g[4] + g[6], g[5] + g[7]) else null
            cv.saveLayer(bounds, bp(blend, alpha, tint))
            inlineComp(cv, e, g, ci, stack)
            cv.restore()
        } else inlineComp(cv, e, g, ci, stack)
    }

    // ---------- Bars ----------

    private fun bars(cv: Canvas, e: El) {
        val idx = e.f("audioProviderIndex", 1f).toInt() - 1
        val pr = provs.getOrNull(idx) ?: provs.firstOrNull() ?: return
        val v = pr.out
        val n = v.size
        val (px, py) = e.f2("position", 0.5f, 0.5f)
        val (sx, sy) = e.f2("scale", 1f, 1f)
        val hs = e.f("heightScale", 1f)
        val minH = e.f("minHeightScale", 0f)
        val circle = e.s("ShapePath") == "Circle"
        val boxW = abs(sx) * W
        val boxH = abs(sy) * H
        val cx = px * W
        val cy = py * H
        val r = nf(e.nested("ShapePath"), "radius", 1f) * min(boxW, boxH) / 2f
        val flip = e.b("flipInput")
        cv.save()
        cv.rotate(e.f("rotation"), cx, cy)
        for (sn in arrayOf("Segment1", "Segment2")) {
            val type = e.s(sn)
            if (type.isEmpty() || type == "None") continue
            val so = e.nested(sn)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.xfermode = xfer(e.s("blendMode"))
            paint.color = ni(so, "colorFrom", -1)
            paint.style = Paint.Style.STROKE
            val bhm = nf(so, "barHeightMultiplier", 1f)
            val bwid = nf(so, "barWidth", 1f)
            val fixed = nf(so, "fixedHeight", 0f)
            val mirror = ni(so, "mirror", 0) != 0
            val arc = if (circle) 2f * PI.toFloat() * r / n else boxW / n
            val unit = if (circle) r else boxH * 0.2f
            if (type == "Line") {
                paint.strokeWidth = max(2f, W / 300f)
                paint.strokeJoin = Paint.Join.ROUND
            } else {
                paint.strokeWidth = max(1f, arc * bwid * 0.8f)
                paint.strokeCap = if (type == "RoundBars") Paint.Cap.ROUND else Paint.Cap.BUTT
            }
            val path = Path()
            val path2 = Path()
            for (i in 0 until n) {
                val vi = v[if (flip) n - 1 - i else i]
                val len = (max(vi * hs * bhm, minH) + fixed * 0.01f) * unit
                val x0: Float
                val y0: Float
                val x1: Float
                val y1: Float
                val x2: Float
                val y2: Float
                if (circle) {
                    val a = -PI.toFloat() / 2f + 2f * PI.toFloat() * i / n
                    val ca = cos(a)
                    val sa = sin(a)
                    val rin = r - if (mirror) len else 0f
                    x0 = cx + ca * rin; y0 = cy + sa * rin
                    x1 = cx + ca * (r + len); y1 = cy + sa * (r + len)
                    x2 = cx + ca * (r - len); y2 = cy + sa * (r - len)
                } else {
                    val x = cx - boxW / 2f + boxW * (i + 0.5f) / n
                    x0 = x; y0 = cy + if (mirror) len else 0f
                    x1 = x; y1 = cy - len
                    x2 = x; y2 = cy + len
                }
                if (type == "Line") {
                    if (i == 0) { path.moveTo(x1, y1); path2.moveTo(x2, y2) } else { path.lineTo(x1, y1); path2.lineTo(x2, y2) }
                } else cv.drawLine(x0, y0, x1, y1, paint)
            }
            if (type == "Line") {
                if (circle) { path.close(); path2.close() }
                cv.drawPath(path, paint)
                if (mirror) cv.drawPath(path2, paint)
            }
        }
        cv.restore()
    }

    // ---------- Particles ----------

    private fun particles(cv: Canvas, e: El) {
        val spr = bitmapFor(e.s("customImage")) ?: return
        val st = ps.getOrPut(e) { PS() }
        val k = W / 1080f
        val c0 = e.hsla("ColorFrom")
        val c1 = e.hsla("ColorTo")
        val mul = e.col("color")
        val fl = st.filters ?: Array(12) { i -> modulate(mulArgb(lerpArgb(c0, c1, i / 11f), mul)) }.also { st.filters = it }
        if (st.frame != frame) {
            st.frame = frame
            val now = System.nanoTime()
            val dt = if (st.last == 0L) 0f else ((now - st.last) / 1e9f).coerceAtMost(0.05f)
            st.last = now
            val (px, py) = e.f2("position", 0.5f, 0.5f)
            val (sx, sy) = e.f2("scale", 1f, 1f)
            val limit = max(20, (min(e.f("CountLimit", 400f), 600f) * (0.3f + 0.7f * quality)).toInt())
            val life = max(e.f("lifetime", 2f), 0.1f)
            val every = max(max(e.f("spawnTime", 0.02f), 0.004f), life / limit)
            val area = e.s("SpawnArea")
            val sa = e.nested("SpawnArea")
            st.acc += dt
            var guard = 0
            while (st.acc >= every && guard < 40) {
                st.acc -= every
                guard++
                if (st.l.size >= limit) continue
                val x = px * W + (Random.nextFloat() - 0.5f) * sx * W
                val y = if (area == "HorizontalLine") py * H else py * H + (Random.nextFloat() - 0.5f) * sy * H
                val ang = if (ni(sa, "useRandomVectorInstead", 0) != 0) Random.nextFloat() * 6.2832f
                else Math.toRadians(nf(sa, "vectorAngle", 90f).toDouble()).toFloat()
                val spd = (e.f("Speed") + (Random.nextFloat() * 2f - 1f) * e.f("speedRandom")) * k
                val sz = (e.f("endSize") + Random.nextFloat() * e.f("endSizeRandom")) * e.f("particleScale", 1f) * 0.1f * k
                st.l.add(Pt(x, y, cos(ang) * spd, -sin(ang) * spd, 0f, life * (0.7f + Random.nextFloat() * 0.3f), max(2f, sz)))
            }
            val (gx, gy) = e.f2("gravity")
            val iter = st.l.iterator()
            while (iter.hasNext()) {
                val p = iter.next()
                p.age += dt
                if (p.age >= p.life) { iter.remove(); continue }
                p.vx += gx * k * dt
                p.vy += gy * k * dt
                p.x += p.vx * dt
                p.y += p.vy * dt
            }
        }
        val fade = max(e.f("fadeInAndOutTime", 0.1f), 0.01f)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.xfermode = xfer(e.s("blendMode"))
        val rect = RectF()
        for (p in st.l) {
            val u = p.age / p.life
            val a = min(1f, min(u / fade, (1f - u) / fade))
            paint.colorFilter = fl[(u * 11f).toInt().coerceIn(0, 11)]
            paint.alpha = (a * 255f).toInt().coerceIn(0, 255)
            val s = p.size * (0.3f + 0.7f * min(1f, u * 5f))
            rect.set(p.x - s / 2f, p.y - s / 2f, p.x + s / 2f, p.y + s / 2f)
            cv.drawBitmap(spr, null, rect, paint)
        }
    }

    // ---------- Text ----------

    private fun text(cv: Canvas, e: El) {
        val i = info
        val s = e.s("text").replace("{TimeCurrent}", fmtTime(i.posMs)).replace("{TimeLength}", fmtTime(i.durMs))
            .replace("{TrackName}", i.title).replace("{TrackTitle}", i.title)
            .replace("{ArtistName}", i.artist).replace("{Artist}", i.artist)
        if (s.isBlank()) return
        val (px, py) = e.f2("position", 0.5f, 0.5f)
        val (sx, _) = e.f2("scale", 1f, 1f)
        val (ax, _) = e.f2("alignmentPosition", 0.5f, 0.5f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = e.col("color")
        p.textSize = max(6f, e.f("fontSize", 40f) * abs(sx) * W / 1080f)
        p.xfermode = xfer(e.s("blendMode"))
        p.textAlign = if (ax < 0.25f) Paint.Align.LEFT else if (ax > 0.75f) Paint.Align.RIGHT else Paint.Align.CENTER
        val tf = e.s("typeFace")
        if (tf.isNotEmpty() && !tf.startsWith("internal")) {
            if (!fonts.containsKey(tf)) fonts[tf] = try { Typeface.createFromFile(File(dir, tf)) } catch (ex: Exception) { null }
            fonts[tf]?.let { p.typeface = it }
        }
        cv.drawText(s, px * W, py * H + p.textSize * 0.35f, p)
    }

    // ---------- RenderNode (повторное воспроизведение без повторной записи) ----------

    private fun canNode(cv: Canvas) = Build.VERSION.SDK_INT >= 29 && cv.isHardwareAccelerated

    private fun node(e: El, tag: Int): RenderNode {
        val key = "${System.identityHashCode(e)}#$tag"
        val n = nodes.getOrPut(key) { RenderNode("dizz$tag") } as RenderNode
        n.setPosition(0, 0, W.toInt(), H.toInt())
        return n
    }

    /** Записывает цель в узел один раз за кадр. */
    private fun record(e: El, tag: Int, name: String, stack: HashSet<Int>): RenderNode {
        val n = node(e, tag)
        val rc = n.beginRecording(W.toInt(), H.toInt())
        try { drawTarget(rc, name, stack) } finally { n.endRecording() }
        return n
    }

    // ---------- Эффекты ----------

    private fun blur(cv: Canvas, e: El, stack: HashSet<Int>) {
        val src = "composition:" + e.f("sourceCompositionIndex").toInt()
        val bm = e.s("blendModeContent", "Add")
        val under = e.b("showUnblurredContentUnder") || e.b("showUnblurredContent")
        if (!canNode(cv)) {
            if (under) {
                cv.saveLayer(null, bp(bm))
                drawTarget(cv, src, stack)
                cv.restore()
            }
            return
        }
        val base = record(e, 0, src, stack)
        if (under) {
            cv.saveLayer(null, bp(bm))
            cv.drawRenderNode(base)
            cv.restore()
        }
        if (Build.VERSION.SDK_INT < 31) return
        // слои свечения объединяем: суммируем цвета включённых слоёв
        var r = 0
        var g = 0
        var b = 0
        var sc = 0f
        for (k in 1..3) {
            val (lx, ly) = e.f2("${k}layerScale", 1f, 1f)
            if (lx <= 0.01f || ly <= 0.01f) continue
            val c = e.col("${k}layerColor")
            r += Color.red(c); g += Color.green(c); b += Color.blue(c)
            if (sc == 0f) sc = (lx + ly) / 2f
        }
        if (sc == 0f) return
        val tint = Color.rgb(min(255, r), min(255, g), min(255, b))
        val glow = node(e, 1)
        val sigma = max(1f, W * 0.004f * e.f("blurMultiplier", 2f) * (0.5f + quality))
        val key = "${System.identityHashCode(e)}#s"
        if (sigmas[key] != sigma) {
            glow.setRenderEffect(RenderEffect.createBlurEffect(sigma, sigma, Shader.TileMode.CLAMP))
            sigmas[key] = sigma
        }
        val rc = glow.beginRecording(W.toInt(), H.toInt())
        try { rc.drawRenderNode(base) } finally { glow.endRecording() }
        cv.saveLayer(null, bp(bm, 1f, tint))
        cv.scale(sc, sc, W / 2f, H / 2f)
        cv.drawRenderNode(glow)
        cv.restore()
    }

    private fun motion(cv: Canvas, e: El, stack: HashSet<Int>) {
        val name = e.s("TargetImage")
        if (trails && motionDepth == 0) {
            val (sx, sy) = e.f2("scale", 1f, 1f)
            val ghost = Paint()
            ghost.alpha = 85
            cv.saveLayer(null, ghost)
            cv.scale(sx, sy, W / 2f, H / 2f)
            motionDepth++
            drawTarget(cv, name, stack)
            motionDepth--
            cv.restore()
        }
        motionDepth++
        drawTarget(cv, name, stack)
        motionDepth--
    }

    private fun rgb(cv: Canvas, e: El, stack: HashSet<Int>) {
        val name = e.s("targetImage").ifEmpty { e.s("TargetImage") }
        val d = abs(e.mv("splitAmount", 0f)) * W * e.mv("splitMultiplier", 1f).coerceIn(0f, 12f)
        if (d < 1.5f) { drawTarget(cv, name, stack); return }   // в покое три слоя дают исходную картинку
        val ox = cos(shake) * d
        val oy = sin(shake) * d
        val cols = intArrayOf(e.col("splitColor0"), e.col("splitColor1"), e.col("splitColor2"))
        val node = if (canNode(cv)) record(e, 0, name, stack) else null
        for (i in 0..2) {
            val s = (i - 1).toFloat()
            cv.saveLayer(null, bp("Add", 1f, cols[i]))
            cv.translate(s * ox, s * oy)
            if (node != null) cv.drawRenderNode(node) else drawTarget(cv, name, stack)
            cv.restore()
        }
    }

    private fun mirror(cv: Canvas, e: El, stack: HashSet<Int>) {
        val name = e.s("TargetImage")
        val mode = e.s("mirrorMode", "Horizontal")
        val flip = e.b("flipMirror")
        val hor = mode.contains("Horizontal")
        val ver = mode.contains("Vertical")
        val hx = W / 2f
        val hy = H / 2f
        val xs = if (hor) intArrayOf(1, -1) else intArrayOf(1)
        val ys = if (ver) intArrayOf(1, -1) else intArrayOf(1)
        val node = if (canNode(cv)) record(e, 0, name, stack) else null
        for (fx in xs) for (fy in ys) {
            cv.save()
            val left = if (!hor) 0f else if ((fx == 1) != flip) 0f else hx
            val right = if (!hor) W else if ((fx == 1) != flip) hx else W
            val top = if (!ver) 0f else if ((fy == 1) != flip) 0f else hy
            val bottom = if (!ver) H else if ((fy == 1) != flip) hy else H
            cv.clipRect(left, top, right, bottom)
            cv.scale(if (fx == -1) -1f else 1f, if (fy == -1) -1f else 1f, hx, hy)
            if (node != null) cv.drawRenderNode(node) else drawTarget(cv, name, stack)
            cv.restore()
        }
    }

    private fun fov(cv: Canvas, e: El, stack: HashSet<Int>) {
        drawTarget(cv, e.s("TargetImage"), stack)
    }
}

object Templates {
    val names = mutableStateListOf<String>()
    var lastError by mutableStateOf("")
    private val scenes = HashMap<String, AveeScene?>()

    private fun root(c: Context) = File(c.filesDir, "viz")

    fun refresh(c: Context) {
        val l = root(c).listFiles { f -> f.isDirectory && File(f, "scene.json").exists() }
            ?.map { it.name }?.sorted() ?: emptyList()
        names.clear()
        names.addAll(l)
    }

    fun scene(c: Context, name: String): AveeScene? {
        if (scenes.containsKey(name)) return scenes[name]
        lastError = ""
        val s = try { AveeScene(File(root(c), name)) } catch (e: Throwable) {
            lastError = "Шаблон не открылся: " + (e.message ?: e.javaClass.simpleName)
            null
        }
        scenes[name] = s
        return s
    }

    /** Распаковывает .viz (ZIP) в приватную папку приложения. Возвращает имя шаблона. */
    fun import(c: Context, uri: Uri): String {
        var disp = "template"
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) disp = it.getString(0) ?: disp
        }
        val base = disp.substringBeforeLast('.').replace(Regex("[^\\p{L}\\p{N}_\\- ]"), "_").trim().ifEmpty { "template" }
        var name = base
        var n = 2
        while (File(root(c), name).exists()) { name = "$base ($n)"; n++ }
        val dir = File(root(c), name)
        dir.mkdirs()
        val canon = dir.canonicalPath + File.separator
        try {
            ZipInputStream(c.contentResolver.openInputStream(uri) ?: throw Exception("Не удалось открыть файл")).use { z ->
                var en = z.nextEntry
                while (en != null) {
                    if (!en.isDirectory) {
                        val out = File(dir, en.name)
                        if (!out.canonicalPath.startsWith(canon)) throw Exception("Некорректный архив")
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o -> z.copyTo(o) }
                    }
                    z.closeEntry()
                    en = z.nextEntry
                }
            }
            if (!File(dir, "scene.json").exists()) throw Exception("В файле нет scene.json — это не шаблон Avee")
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
        return name
    }

    fun delete(c: Context, name: String) {
        scenes.remove(name)
        File(root(c), name).deleteRecursively()
        refresh(c)
    }
}
